#!/bin/bash
#reading input string
read string

#PART A
len=${#string}
for ((i = $len - 1; i>=0; i--))
do
rev="$rev${string:$i:1}"
done
echo $rev

#PART B
for ((i = $len - 1; i>=0; i--))
do
echo -n "${rev[i]}" | tr 'a-zA-Z' 'b-zaB-ZA'
done
echo

#PART C
var=$(($len/2))
for ((j = $var - 1; j>=0; j--))
do
new="$new${string:$j:1}"
done
for ((j = $var; j<$len; j++))
do
new="$new${string:$j:1}"
done
echo $new