#!/bin/bash
#read file name
read string
#Part A
size=$(wc -c < $string)
echo $size

#Part B
echo $(wc -l < $string)

#Part C
echo $(wc -w < $string)

#Part D
i=1
while IFS= read -r line; do
    echo -n "Line No: $i - Count of Words: " ; echo "$line" | awk '{print NF}'
    let i+=1
done < $string

#Part E
grep -E -o '\w++' $string | sort > new.txt
uniq -c new.txt > count.txt
while read -r line;
do
arr=($line)
if (($((${arr[0]}-1))==0))
then
continue
else
echo "Word : ${arr[1]} - Count of Repetitions : $((${arr[0]}-1))"
fi
done < count.txt

rm -r count.txt new.txt