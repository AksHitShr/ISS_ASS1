#!/bin/bash

#read as string
read string
IFS=',' read -r -a arr <<< "$string"
num=${#arr[*]}

#Bubble sort 
for ((i = 0; i<num; i++))
do
    for((j = 0; j<num-i-1; j++))
    do
        if [ ${arr[j]} -gt ${arr[$((j+1))]} ]
        then
            # swap
            temp=${arr[j]}
            arr[$j]=${arr[$((j+1))]}  
            arr[$((j+1))]=$temp
        fi
    done
done

#print
echo ${arr[*]}