#!/bin/bash
#Q1 Part A
#REMOVE BLANK LINES
sed '/^$/d' quotes.txt

#Q1 Part B
#removing duplicate sentences
awk '!x[$0]++' quotes.txt